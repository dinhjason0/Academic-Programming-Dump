﻿using System;

//Jason Truong

namespace Lesson_Git
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello git and GitHub");
        }
    }
}

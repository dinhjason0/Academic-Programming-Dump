using System;

namespace PCE_StarterProject
{
    class Program
    {
        static void Main(string[] args)
        {
            // Conditional_Statements cs = new Conditional_Statements();
            // cs.RunExercise();

            // Comparison_Operators co = new Comparison_Operators();
            // co.RunExercise();

            // IO_Operators ioo = new IO_Operators();
            // ioo.RunExercise();
            
            // Integer_Vs_Real_Division ivrd = new Integer_Vs_Real_Division();
            // ivrd.RunExercise();

            // Clearly, you will need to uncomment these to test them...
            // Modulus_Operator mo = new Modulus_Operator();
            // mo.RunExercise();

            // Fahrenheit_To_Celsius ftc = new Fahrenheit_To_Celsius();
            // ftc.RunExercise();
         }
    }

    class Conditional_Statements
    {
        public void RunExercise()
        {
            Console.WriteLine("About to do the \"Conditional Statements\" exercise");
            Conditional_Methods cm = new Conditional_Methods();
            cm.UsingIf();
            cm.UsingIfElse();
            cm.UsingSwitch();
        }
    }

    class Comparison_Operators
    {
        public void RunExercise()
        {
            Console.WriteLine("Get 2 integers & store them, then compare them using <, <=, etc, etc");
        }
    }


    class IO_Operators
    {
        public void RunExercise()
        {
        }
    }

    class Conditional_Methods
    {
        public void UsingIf()
        {
        }

        public void UsingIfElse()
        {
        }
        public void UsingSwitch()
        {
        }
    }

    class Integer_Vs_Real_Division
    {
        public void RunExercise()
        {
        }
    }

    class Modulus_Operator
    {
        public void RunExercise()
        {
        }
    }

    class Fahrenheit_To_Celsius
    {
        public void RunExercise()
        {
        }
    }

    class Logical_Operators
    {
        // Your answer goes here,in a comment like this one

        // Side-Note: Notice that this class has NO methods, and that it still compiles :)
    }
}
# BIT-142-Lesson-02

This is the starter project for lesson 02 for BIT 142.

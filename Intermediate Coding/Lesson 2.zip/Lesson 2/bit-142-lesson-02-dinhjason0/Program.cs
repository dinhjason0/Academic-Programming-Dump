﻿//JASON TRUONG
using System;

namespace Lesson_Git
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello Git And GitHub. Standing on a wheel-chair is not safe for work.");
        }
    }
}

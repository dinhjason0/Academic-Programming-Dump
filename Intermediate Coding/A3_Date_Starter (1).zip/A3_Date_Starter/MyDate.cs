﻿using System;

namespace MyDate_StudentWork
{
    class MyDate // You will need to fill this in! :)
    {
        public MyDate()
        {
        }

        public MyDate(int month, int day)
        {
        }

        public int getDay()
        {
            return -1;
        }

        public int getMonth()
        {
            return -1;
        }

        public void setDate(int month, int day)
        {
        }

        public string toString()
        {
            return "NOT WORKING";
        }

        public bool equals(int otherDatesMonth, int otherDatesDay)
        {
            return false;
        }

        public int daysInMonth()
        {
            return -1;
        }

        public void nextDay()
        {
        }
    }
}
